
import { Component, inject } from '@angular/core';
import { UserService } from '../../core/services/user';

@Component({
  selector: 'app-settings',
  standalone: true,
  templateUrl: './settings.html',
  styleUrl: './settings.scss'
})
export class SettingsComponent {

  private userService = inject(UserService);

  userName = this.userService.userName;

}
