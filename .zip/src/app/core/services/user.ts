
import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  // Private user name storage
  private _userName = signal('Alex Morgan');

  // Public read-only user name
  readonly userName = this._userName.asReadonly();

  // Update user name through a service method
  updateUserName(name: string) {
    this._userName.set(name);
  }
}
